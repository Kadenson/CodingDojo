var childheight = 50;
var childage = 11
if (childheight <= 52 || childage <= 10) {
    console.log ("Sorry, kiddo maybe next year");
}
else { 
    console.log ("Get on that ride kiddo");
}

var childheight = 53;
var childage = 11
if (childheight >= 52 && childage >= 10) {
    console.log ("Get on that ride kiddo");
}
else { 
    console.log ("Sorry, kiddo maybe next year");
}