//Used x,y,z variables to seperate time and different Jedi's
var x = 'Goodnight ObiWan.'
var y = 'Afternoon Master Yoda.'
var z = 'Morning Young Skywalker.'
function CountDooku(){
    console.log("I'm coming for you, Dooku!!!");//calling CountDooku will console.log this
}
function greet(Jedi){
    if(Jedi == 'Anakin' || Jedi === 'Yoda'){
        console.log('Good day, '+ Jedi);
    }
    else if(Jedi == 'Ben'){
        console.log(x)
    }
    else if(Jedi == 'Master'){
        console.log(y)
    }
    else if(Jedi == 'Young'){
        console.log(z);
    }
}
greet('Master');
