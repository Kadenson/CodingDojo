/*1.One way to solve this would be to use if statements. Using these if statements we can compare the keywords that make writing first
second or third person.*/

/*2. This would be an example of psuedo-code for this problem
if(var firstP = 'I' || ' we'){
    paragraph = firstP
}
you would then repeat that for second and third person as well*/

/*3. The hardest part of problem-solving for me personally is trying to organize my thoughts into a complete solution and 
figuring out how to get to that solution.