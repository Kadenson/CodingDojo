//The console.log will state "I was born in 1980"
//The console.log will state "I was born in 1980"
//The console.log will state "Summing numbers" "num1: is 10" "num2: is 20" "30"